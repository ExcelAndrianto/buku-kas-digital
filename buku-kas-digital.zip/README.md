# Buku Kas Digital Sederhana

Aplikasi sederhana berbasis CLI (Command Line) menggunakan Python untuk mencatat pemasukan dan pengeluaran harian. Data disimpan ke file CSV (`kas.csv`).

## Fitur:
- Tambah Pemasukan
- Tambah Pengeluaran
- Lihat semua transaksi
- Hitung saldo akhir

## Cara Menjalankan

```bash
python main.py
```

## Tujuan Project
Melatih penggunaan Python dasar dan file CSV sebagai database sederhana.
