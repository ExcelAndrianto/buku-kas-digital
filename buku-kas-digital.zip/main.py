import csv
import os

FILE_NAME = 'kas.csv'

# Inisialisasi file jika belum ada
if not os.path.exists(FILE_NAME):
    with open(FILE_NAME, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Tanggal', 'Tipe', 'Keterangan', 'Jumlah'])

def tambah_transaksi(tipe):
    tanggal = input("Tanggal (YYYY-MM-DD): ")
    keterangan = input("Keterangan: ")
    jumlah = int(input("Jumlah: "))

    with open(FILE_NAME, 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([tanggal, tipe, keterangan, jumlah])
    
    print(f"{tipe} berhasil ditambahkan!")

def lihat_transaksi():
    with open(FILE_NAME, 'r') as file:
        reader = csv.reader(file)
        next(reader)  # Skip header
        for row in reader:
            print(row)

def lihat_saldo():
    saldo = 0
    with open(FILE_NAME, 'r') as file:
        reader = csv.reader(file)
        next(reader)
        for row in reader:
            tipe, jumlah = row[1], int(row[3])
            if tipe == 'Pemasukan':
                saldo += jumlah
            elif tipe == 'Pengeluaran':
                saldo -= jumlah
    print(f"Saldo saat ini: Rp{saldo:,}")

def menu():
    while True:
        print("\n=== Buku Kas Digital ===")
        print("1. Tambah Pemasukan")
        print("2. Tambah Pengeluaran")
        print("3. Lihat Semua Transaksi")
        print("4. Lihat Saldo")
        print("5. Keluar")

        pilihan = input("Pilih menu (1-5): ")

        if pilihan == '1':
            tambah_transaksi("Pemasukan")
        elif pilihan == '2':
            tambah_transaksi("Pengeluaran")
        elif pilihan == '3':
            lihat_transaksi()
        elif pilihan == '4':
            lihat_saldo()
        elif pilihan == '5':
            break
        else:
            print("Pilihan tidak valid.")

if __name__ == "__main__":
    menu()
